# Mettiamo qua codice utile
# Ognuno esegue la roba in locale
